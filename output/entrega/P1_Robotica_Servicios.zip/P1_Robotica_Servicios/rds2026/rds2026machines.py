#!/usr/bin/python
# encoding: utf-8
"""Modelo de la aspiradora: posición, sensores, avance, batería y dibujo.

La posición es el centro del cuerpo, no su esquina. Un update permite avanzar
medio paso. El sensor frontal comprueba si la huella futura toca un obstáculo;
el algoritmo puede consultarlo antes de ordenar ese update.
"""

import math, pygame
from random import randint

# Huella cuadrada 2x2; cada update avanza 0,5 unidades si está en marcha.
# La rejilla de A/B coincide con este paso para poder alcanzar sus objetivos.
VACUUM_SIZE = 2
VACUUM_SPEED = VACUUM_SIZE/4.0

BATTERY_SIZE = 100_000_000

#
# básico
#
class vacuum():
    """Robot básico que se detiene cuando el siguiente movimiento está bloqueado."""

    objects = None
    chargers = None

    vacuum_img = None
    vacuum_img_bak = None

    position = (0, 0)
    velocity = (0, 0)
    orientation = 0
    is_running = False
    running_on_battery = False

    stats_collisions = 0
    current_collision_already_counted = False
    forward_path_is_blocked = False

    sensor = {
        'position': (0, 0),
        'orientation': 0,
        'proximity': {'left':False, 'front':False, 'right':False},
        'detection': '',
        'cells': [None, None, None, None],
        'battery': BATTERY_SIZE
    }

    screen = None
    proximity_bbox = {'left':None, 'front':None, 'right':None}

    def __init__(self, position, orientation, simulate_battery = False):
        """Inicializar un robot independiente; por defecto no consumir batería."""
        self.position = (position[0], position[1])
        self.orientation = orientation
        self.running_on_battery = simulate_battery
        # Estado propio de cada robot: evita compartir sensores y contadores
        # entre simulaciones. La odometría empieza en la posición real indicada;
        # el modelo la actualiza sin ruido, una simplificación del simulador.
        self.velocity = (0, 0)
        self.is_running = False
        self.stats_collisions = 0
        self.current_collision_already_counted = False
        self.forward_path_is_blocked = False
        self.sensor = {
            'position': self.position,
            'orientation': self.orientation,
            'proximity': {'left': False, 'front': False, 'right': False},
            'detection': '',
            'cells': [None, None, None, None],
            'battery': BATTERY_SIZE
        }
        self.proximity_bbox = {'left': None, 'front': None, 'right': None}

    def init_images(self, screen, static_objects, recharge_tiles):
        """Preparar la imagen 2x2 y enlazar obstáculos/cargadores del simulador."""
        self.screen = screen
        dd = screen['window']['density']
        self.objects = static_objects
        self.chargers = recharge_tiles
        # image
        img = pygame.transform.scale(
            pygame.image.load("img/vacuum.png"),
                (VACUUM_SIZE * dd, VACUUM_SIZE * dd)
        )
        img_rect = img.get_rect()
        img_rect.x = (self.position[0] - VACUUM_SIZE//2) * dd
        img_rect.y = (self.position[1] - VACUUM_SIZE//2) * dd
        self.vacuum_img = {'img':img, 'bbox':img_rect.copy()}
        self.vacuum_img_bak = {'img':img.copy(), 'bbox':img_rect.copy()}
        # sensors
        self.check_proximity()
        self.check_cells()

    def check_proximity(self):
        """Actualizar los tres booleanos de proximidad sin desplazar el robot."""
        # Modelo del sensor: intersectar la huella del siguiente paso con los
        # obstáculos del simulador. El algoritmo de la práctica solo consulta
        # los booleanos resultantes; no inspecciona esta lista de objetos.
        # front
        dd = self.screen['window']['density']
        t1 = self.vacuum_img['bbox'].copy()
        # Calculamos la posición futura antes de convertirla a píxeles enteros.
        # Convertir posición y desplazamiento por separado redondeaba dos veces
        # y podía hacer que un paso funcionara al ir pero fallara al regresar.
        t1.x = (self.position[0] + self.velocity[0] - VACUUM_SIZE//2) * dd
        t1.y = (self.position[1] + self.velocity[1] - VACUUM_SIZE//2) * dd
        # left
        t0 = t1.copy()
        t0.x += (self.velocity[1] * dd)
        t0.y -= (self.velocity[0] * dd)
        # right
        t2 = t1.copy()
        t2.x -= (self.velocity[1] * dd)
        t2.y += (self.velocity[0] * dd)
        self.sensor['proximity'] = {'left':False, 'front':False, 'right':False}
        self.sensor['detection'] = ''
        for i in self.objects:
            if self.sensor['proximity']['front'] == False and i['bbox'].colliderect(t1):
                self.sensor['proximity']['front'] = True
                self.sensor['detection'] = i['desc']
            if self.sensor['proximity']['left'] == False and i['bbox'].colliderect(t0):
                self.sensor['proximity']['left'] = True
            if self.sensor['proximity']['right'] == False and i['bbox'].colliderect(t2):
                self.sensor['proximity']['right'] = True
        self.proximity_bbox = {'left':t0, 'front':t1, 'right':t2}

    def check_cells(self):
        """Indicar cuatro celdas bajo la huella; no reconstruir el plano entero."""
        # Cuatro muestras bajo el cuerpo. floor asigna cada coordenada continua
        # a una celda de suelo; estas muestras también se usan para la cobertura.
        self.sensor['cells'][0] = (
            math.floor(self.sensor['position'][0] - VACUUM_SIZE/4.0),
            math.floor(self.sensor['position'][1] - VACUUM_SIZE/4.0)
        )
        self.sensor['cells'][1] = (
            math.floor(self.sensor['position'][0] + VACUUM_SIZE/4.0),
            math.floor(self.sensor['position'][1] - VACUUM_SIZE/4.0)
        )
        self.sensor['cells'][2] = (
            math.floor(self.sensor['position'][0] - VACUUM_SIZE/4.0),
            math.floor(self.sensor['position'][1] + VACUUM_SIZE/4.0)
        )
        self.sensor['cells'][3] = (
            math.floor(self.sensor['position'][0] + VACUUM_SIZE/4.0),
            math.floor(self.sensor['position'][1] + VACUUM_SIZE/4.0)
        )

    def check_collision_in_next_step(self):
        """True si el próximo avance está bloqueado; todavía no contar un choque."""
        self.check_proximity()
        return self.sensor['proximity']['front']

    def start(self):
        """Activar avance: 0° derecha, 90° arriba, 180° izquierda, 270° abajo."""
        self.is_running = True
        velocity = (
            (VACUUM_SPEED * math.cos(self.orientation * math.pi/180.0)),
            -(VACUUM_SPEED * math.sin(self.orientation * math.pi/180.0))
        )
        # cos/sin pueden dejar residuos para 90/180 grados. Anularlos impide
        # que un movimiento cardinal derive lentamente fuera de su fila/columna.
        self.velocity = tuple(0.0 if abs(v) < 1e-12 else v for v in velocity)

    def stop(self):
        """Anular velocidad y avance, conservando posición y orientación."""
        self.is_running = False
        self.velocity = (0, 0)

    def recharge(self):
        """Restablecer batería únicamente si el cuerpo se solapa con un cargador."""
        # La huella de recarga usa X e Y de la posición, en unidades del mundo.
        ll = pygame.Rect(
            (self.position[0] - VACUUM_SIZE//2,
            self.position[1] - VACUUM_SIZE//2),
            (VACUUM_SIZE, VACUUM_SIZE)
        )
        for r in self.chargers:
            tile = pygame.Rect((r[0], r[1]), (1, 1))
            if ll.colliderect(tile):
                self.sensor['battery'] = BATTERY_SIZE
                print("DEBUG: recharged battery")
                return
        print("DEBUG: not over a recharge tile!")

    def rotate(self, n):
        """Sumar n grados sin traslación; recalcular velocidad si estaba avanzando."""
        if self.running_on_battery: self.sensor['battery'] -= (abs(math.floor(n/15.0)))
        if self.sensor['battery'] > 0:
            self.forward_path_is_blocked = False
            self.orientation += n
            self.orientation %= 360
            if self.is_running == True:
                velocity = (
                    (VACUUM_SPEED * math.cos(self.orientation*math.pi/180.0)),
                    -(VACUUM_SPEED * math.sin(self.orientation*math.pi/180.0))
                )
                self.velocity = tuple(0.0 if abs(v) < 1e-12 else v for v in velocity)
            # update
            self.sensor['orientation'] += n
            self.sensor['orientation'] %= 360
            # sensors
            #self.check_proximity()
            #self.check_cells()
            # update image
            r_img = pygame.transform.rotate(self.vacuum_img_bak['img'], self.orientation)
            p_img = r_img.get_rect().center
            c_img = r_img.subsurface(pygame.Rect(
                ((p_img[0] - self.vacuum_img['bbox'].width//2),
                (p_img[1] - self.vacuum_img['bbox'].height//2)),
                (self.vacuum_img['bbox'].width, self.vacuum_img['bbox'].height))
            )
            self.vacuum_img = {'img':c_img, 'bbox':self.vacuum_img['bbox']}
        else:
            print("DEBUG: empty battery!")
            self.stop()

    def collision_strategy(self):
        """Reacción por defecto a un avance bloqueado: detenerse, sin planificar."""
        self.stop()

    def update(self):
        # Un ciclo del simulador: detectar, mover si procede, actualizar la
        # odometría y dibujar. En la teleoperación también se aplica este bloqueo.
        dd = self.screen['window']['density']
        self.check_proximity()
        if self.is_running:
            if not self.check_collision_in_next_step():
                # running free and moving
                if self.running_on_battery: self.sensor['battery'] -= 1
                if self.sensor['battery'] > 0:
                    self.position = (
                        self.position[0] + self.velocity[0],
                        self.position[1] + self.velocity[1]
                    )
                    self.current_collision_already_counted = False
                    # update
                    self.sensor['position'] = (
                        self.sensor['position'][0] + self.velocity[0],
                        self.sensor['position'][1] + self.velocity[1]
                    )
                    # sensors
                    self.check_proximity()
                    self.check_cells()
                else:
                    print("DEBUG: empty battery!")
                    self.stop()
            else:
                # collision
                self.collision_strategy()
                if self.current_collision_already_counted == False:
                    # Contar una obstrucción una sola vez hasta volver a avanzar.
                    self.current_collision_already_counted = True
                    self.stats_collisions += 1
                    self.forward_path_is_blocked = True
                    if self.screen['debugging']:
                        print("DEBUG: collision with '{}'".format(self.sensor['detection']))
            self.check_cells()
        # show
        rect = self.vacuum_img['bbox'].copy()
        rect.x = (self.position[0] - VACUUM_SIZE//2) * dd
        rect.y = (self.position[1] - VACUUM_SIZE//2) * dd
        # robot main image
        self.screen['display'].blit(self.vacuum_img['img'], rect.copy())
        # lines after collision
        if self.current_collision_already_counted:
            if not self.screen['debugging']:
                # lines
                pygame.draw.circle(self.screen['display'], (250, 0, 0),
                    (rect.x+rect.width//2, rect.y+rect.height//2),
                    int(0.6*VACUUM_SIZE * dd), 1)
                pygame.draw.circle(self.screen['display'], (250, 0, 0),
                    (rect.x+rect.width//2, rect.y+rect.height//2),
                    int(0.7*VACUUM_SIZE * dd), 1)
        if self.screen['debugging']:
            # robot
            pygame.draw.rect(self.screen['display'], (250, 50, 50), rect, 2)
            # proximity sensor
            pygame.draw.rect(self.screen['display'], (250, 50, 250), self.proximity_bbox['left'],
                 2 if self.sensor['proximity']['left'] else 1)
            pygame.draw.rect(self.screen['display'], (250, 50, 250), self.proximity_bbox['front'],
                 2 if self.sensor['proximity']['front'] else 1)
            pygame.draw.rect(self.screen['display'], (250, 50, 250), self.proximity_bbox['right'],
                 2 if self.sensor['proximity']['right'] else 1)
                 
class vacuum_rotator(vacuum):
    """Ejemplo original: reacción aleatoria; no se utiliza en los apartados A/B/C."""
    def collision_strategy(self):
        self.rotate(randint(-45, +45))

class vacuum_zero(vacuum):
    """Variante del modelo básico que no aplica maniobras tras una colisión."""
    def collision_strategy(self):
        None
