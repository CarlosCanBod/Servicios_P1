#!/usr/bin/python
# encoding: utf-8
"""Coordinar ventana, teclado, mundo y robot en cada ciclo de simulación.

Orden de dibujo: suelo/obstáculos -> robot -> objetos superiores/overlay.
Los algoritmos llaman update para ejecutar el siguiente ciclo físico.
"""

import pygame
from pygame.locals import *

class simulation():
    """Conectar un escenario con un robot y decidir cuándo actualizar ambos."""

    environment = None
    machine = None
    is_running = False

    def __init__(self, size, fps, environment, machine = None):
        """size mide píxeles de ventana; fps limita ciclos por segundo, no metros."""
        self.screen = {
            'display': None,
            'window': {
                'size': size,
                'density': -1,
                'fps': fps,
            },
            'debugging': False
        }
        self.clock = None
        # Escala gráfica: píxeles por celda del escenario. Usar el tamaño aquí
        # corresponde al dibujo del simulador, no al mapa descubierto por A.
        self.screen['window']['density'] = min(
            size[0] // environment.size[0],
            size[1] // environment.size[1]
        )

        # init models
        self.environment = environment
        self.environment.init_images(self.screen)

        self.machine = machine
        if machine is not None:
            self.machine.init_images(
                self.screen,
                self.environment.objects,
                self.environment.recharge_tiles
            )

    def start(self, debug = False):
        """Abrir la ventana e iniciar robot/reloj; A/B/C pueden detenerlo después."""
        pygame.init()
        self.screen['display'] = pygame.display.set_mode((
            self.screen['window']['size'][0],
            self.screen['window']['size'][1]
        ))
        pygame.display.set_caption('rds2026 SIM')
        self.clock = pygame.time.Clock()
        self.is_running = True
        if debug == True:
            self.screen['debugging'] = True
        if self.machine is not None:
            self.machine.start()
        if debug == True:
            print("DEBUG: window: {}".format(self.screen))

    def stop(self):
        """Detener el robot y liberar pygame, también al finalizar un diagnóstico."""
        self.is_running = False
        if self.machine is not None:
            self.machine.stop()
        pygame.quit()

    def read_keyboard(self):
        """Retirar eventos pendientes para que teleoperate interprete las teclas."""
        return pygame.event.get()

    def update(self):
        """Procesar eventos pendientes, ejecutar un paso físico y repintar pantalla."""
        # Procesar eventos y avanzar el mundo un paso. El controlador autónomo
        # llama a este método cada vez que permite un movimiento físico.
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    self.is_running = False
                elif event.key == pygame.K_SPACE:
                    if self.machine.is_running:
                        self.machine.stop()
                    else:
                        self.machine.start()
                elif event.key == pygame.K_d:
                    if self.screen['debugging'] == True:
                        self.screen['debugging'] = False
                    else:
                        self.screen['debugging'] = True

        if self.environment is not None:
            self.environment.update()
        if self.machine is not None:
            self.machine.update()
        if self.environment is not None:
            self.environment.update_extra()
        # El dibujo no controla la física. FPS limita el tiempo entre ciclos;
        # FPS=0 quita la espera para acelerar los diagnósticos.
        pygame.display.update()
        self.clock.tick(self.screen['window']['fps'])
